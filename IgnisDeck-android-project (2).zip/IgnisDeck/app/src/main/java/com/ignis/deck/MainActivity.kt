package com.ignis.deck

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    private val red = Color.parseColor("#FF2A1F")
    private val panel = Color.parseColor("#1A100E")
    private val mute = Color.parseColor("#A38A84")
    private lateinit var prefs: SharedPreferences
    private lateinit var ramV: TextView
    private lateinit var tempV: TextView
    private lateinit var batV: TextView
    private lateinit var pingV: TextView
    private lateinit var gamesRow: LinearLayout
    private lateinit var usageBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { updateStats(); handler.postDelayed(this, 2500) }
    }
    private val nm get() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun label(t: String, sp: Float, c: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = sp; setTextColor(c)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); background = box(panel, 14); setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ignis", MODE_PRIVATE)
        window.statusBarColor = Color.parseColor("#0D0807")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0D0807")) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        scroll.addView(col)
        col.addView(label("IGNIS DECK", 28f, red, true))
        col.addView(label("ศูนย์รวมเกม ช่วยให้เล่นลื่นขึ้น", 13f, mute))

        val row = LinearLayout(this).apply { setPadding(0, dp(16), 0, 0) }
        ramV = statCard(row, "RAM ใช้")
        tempV = statCard(row, "อุณหภูมิ")
        batV = statCard(row, "แบต")
        pingV = statCard(row, "ปิง")
        col.addView(row)
        col.addView(btn("ล้าง RAM ตอนนี้") { cleanNow() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })

        col.addView(head("เกมของฉัน"))
        gamesRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        col.addView(HorizontalScrollView(this).apply { addView(gamesRow) })
        col.addView(btn("+ เลือกเกมจากเครื่อง") { pickGames() }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        usageBtn = btn("ให้สิทธิ์ดูเวลาเล่นเกมวันนี้") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        col.addView(usageBtn, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
        col.addView(label("แตะเกมเพื่อเปิด • กดค้างเพื่อลบออกจากรายการ", 12f, mute))

        col.addView(head("ก่อนเข้าเกม"))
        addSwitch(col, "clean", "ปิดแอปพื้นหลังก่อนเข้าเกม", true, null)
        addSwitch(col, "dnd", "โหมดห้ามรบกวน (ปิดแจ้งเตือนทั้งหมด)", false) {
            if (nm.isNotificationPolicyAccessGranted) true else {
                toast("อนุญาตสิทธิ์ห้ามรบกวนให้ Ignis Deck แล้วกลับมาเปิดสวิตช์อีกครั้ง")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); false
            }
        }
        addSwitch(col, "bright", "ล็อกความสว่างหน้าจอ", false) {
            if (Settings.System.canWrite(this)) true else {
                toast("อนุญาตการแก้ไขการตั้งค่าระบบ แล้วกลับมาเปิดสวิตช์อีกครั้ง")
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))); false
            }
        }
        addSwitch(col, "overlay", "แสดง RAM / อุณหภูมิ / ปิง ลอยบนหน้าจอเกม", false) {
            if (Settings.canDrawOverlays(this)) true else {
                toast("อนุญาต 'แสดงทับแอปอื่น' ให้ Ignis Deck แล้วกลับมาเปิดสวิตช์อีกครั้ง")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); false
            }
        }
        col.addView(label("ออกจากเกมแล้วกลับมาที่แอปนี้ ระบบจะคืนค่าห้ามรบกวนและความสว่าง และปิดตัวเลขลอยให้อัตโนมัติ\n\nปิง = เวลาเชื่อมต่อไปยัง 1.1.1.1 ใช้ประมาณคุณภาพเน็ต ไม่ใช่ปิงของเซิร์ฟเวอร์เกม", 12f, mute))
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        restore()
        usageBtn.visibility = if (hasUsage()) View.GONE else View.VISIBLE
        renderGames()
        handler.post(ticker)
    }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    private fun head(t: String) = label(t, 15f, Color.parseColor("#F4A493"), true).apply { setPadding(0, dp(22), 0, dp(10)) }

    private fun statCard(parent: LinearLayout, name: String): TextView {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = box(panel, 14); setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        val v = label("-", 16f, Color.WHITE, true)
        c.addView(v); c.addView(label(name, 11f, mute))
        parent.addView(c, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        return v
    }

    private fun addSwitch(col: LinearLayout, key: String, title: String, def: Boolean, guard: (() -> Boolean)?) {
        val s = Switch(this).apply {
            text = title; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14)); background = box(panel, 14)
            isChecked = prefs.getBoolean(key, def)
        }
        s.setOnCheckedChangeListener { v, on ->
            if (on && guard != null && !guard()) { v.isChecked = false; return@setOnCheckedChangeListener }
            prefs.edit().putBoolean(key, on).apply()
        }
        col.addView(s, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun updateStats() {
        ramV.text = "${Stats.ramPct(this)}%"
        val t = Stats.temp(this)
        tempV.text = String.format("%.1f°", t)
        tempV.setTextColor(if (t >= 42) red else Color.WHITE)
        batV.text = "${Stats.batt(this)}%"
        Thread {
            val p = Stats.ping()
            runOnUiThread { pingV.text = if (p < 0) "-" else "$p ms" }
        }.start()
    }

    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    private fun playToday(): Map<String, Long> {
        if (!hasUsage()) return emptyMap()
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val list = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis())
            ?: return emptyMap()
        val out = HashMap<String, Long>()
        for (s in list) out[s.packageName] = (out[s.packageName] ?: 0L) + s.totalTimeInForeground
        return out
    }

    private fun fmt(ms: Long): String {
        val m = ms / 60000
        return if (m >= 60) "${m / 60} ชม. ${m % 60} น." else "$m น."
    }

    private fun launcherApps(): List<Pair<String, String>> {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(q, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
    }

    private fun pickGames() {
        val apps = launcherApps()
        val cur = prefs.getStringSet("games", emptySet())!!.toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].first in cur }
        AlertDialog.Builder(this).setTitle("เลือกเกม")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, on ->
                if (on) cur.add(apps[i].first) else cur.remove(apps[i].first)
            }
            .setPositiveButton("บันทึก") { _, _ -> prefs.edit().putStringSet("games", cur).apply(); renderGames() }
            .setNegativeButton("ยกเลิก", null).show()
    }

    private fun renderGames() {
        gamesRow.removeAllViews()
        val pkgs = prefs.getStringSet("games", emptySet())!!.sorted()
        if (pkgs.isEmpty()) gamesRow.addView(label("ยังไม่มีเกม กดปุ่มด้านล่างเพื่อเพิ่ม", 13f, mute))
        val play = playToday()
        for (p in pkgs) {
            val info = (try { packageManager.getApplicationInfo(p, 0) } catch (e: Exception) { null }) ?: continue
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), 0, dp(6), 0) }
            item.addView(ImageView(this).apply { setImageDrawable(packageManager.getApplicationIcon(info)) }, LinearLayout.LayoutParams(dp(60), dp(60)))
            item.addView(label(packageManager.getApplicationLabel(info).toString(), 11f).apply {
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; width = dp(76)
            })
            if (play.isNotEmpty()) item.addView(label("วันนี้ ${fmt(play[p] ?: 0L)}", 10f, mute).apply { gravity = Gravity.CENTER })
            item.setOnClickListener { launchGame(p) }
            item.setOnLongClickListener {
                val s = prefs.getStringSet("games", emptySet())!!.toMutableSet(); s.remove(p)
                prefs.edit().putStringSet("games", s).apply(); renderGames(); true
            }
            gamesRow.addView(item)
        }
    }

    private fun cleanRam(except: String): Int {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val list = launcherApps().map { it.first }.filter { it != except }
        list.forEach { am.killBackgroundProcesses(it) }
        return list.size
    }

    private fun cleanAndReport(except: String) {
        val before = Stats.avail(this)
        val n = cleanRam(except)
        handler.postDelayed({
            val freed = (Stats.avail(this) - before) / 1048576
            toast("สั่งปิดแอปพื้นหลัง $n แอป • RAM ว่างเพิ่ม ${if (freed < 0) 0 else freed} MB")
        }, 1500)
    }

    private fun cleanNow() = cleanAndReport("")

    private fun launchGame(p: String) {
        val intent = packageManager.getLaunchIntentForPackage(p) ?: return toast("เปิดเกมนี้ไม่ได้")
        val e = prefs.edit()
        if (prefs.getBoolean("clean", true)) cleanAndReport(p)
        if (prefs.getBoolean("dnd", false) && nm.isNotificationPolicyAccessGranted) {
            e.putInt("prevFilter", nm.currentInterruptionFilter).putBoolean("dndOn", true)
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        }
        if (prefs.getBoolean("bright", false) && Settings.System.canWrite(this)) {
            val cr = contentResolver
            e.putInt("prevMode", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 1))
                .putInt("prevBright", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128))
                .putBoolean("brightOn", true)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, 200)
        }
        e.apply()
        if (prefs.getBoolean("overlay", false) && Settings.canDrawOverlays(this)) {
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        startActivity(intent)
    }

    private fun restore() {
        stopService(Intent(this, OverlayService::class.java))
        if (prefs.getBoolean("dndOn", false) && nm.isNotificationPolicyAccessGranted)
            nm.setInterruptionFilter(prefs.getInt("prevFilter", NotificationManager.INTERRUPTION_FILTER_ALL))
        if (prefs.getBoolean("brightOn", false) && Settings.System.canWrite(this)) {
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, prefs.getInt("prevMode", 1))
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, prefs.getInt("prevBright", 128))
        }
        prefs.edit().putBoolean("dndOn", false).putBoolean("brightOn", false).apply()
    }
}
