package com.ignis.deck

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var tv: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var ping = -1
    @Volatile private var running = true
    private val tick = object : Runnable {
        override fun run() { tv?.text = line(); handler.postDelayed(this, 1000) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ignis", "Ignis Deck", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "ignis")
            .setContentTitle("Ignis Deck กำลังแสดงสถานะบนหน้าจอ")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); setPadding(24, 12, 24, 12)
            background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 24f }
            text = line()
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 80 }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(v, lp)
                }
            }
            true
        }
        try { wm.addView(v, lp); tv = v } catch (e: Exception) { stopSelf(); return }
        Thread { while (running) { ping = Stats.ping(); try { Thread.sleep(3000) } catch (e: Exception) { } } }.start()
        handler.post(tick)
    }

    private fun line(): String =
        "RAM ${Stats.ramPct(this)}%  แบต ${Stats.batt(this)}%  ${"%.1f".format(Stats.temp(this))}°C  ปิง ${if (ping < 0) "-" else "$ping ms"}"

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        try { tv?.let { wm.removeView(it) } } catch (e: Exception) { }
        super.onDestroy()
    }
}
