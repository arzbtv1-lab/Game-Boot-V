package com.ignis.deck

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.net.InetSocketAddress
import java.net.Socket

object Stats {
    private fun mem(c: Context): ActivityManager.MemoryInfo {
        val mi = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi
    }
    fun avail(c: Context): Long = mem(c).availMem
    fun ramPct(c: Context): Long { val m = mem(c); return 100 - m.availMem * 100 / m.totalMem }
    private fun bat(c: Context): Intent? = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    fun temp(c: Context): Double = (bat(c)?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
    fun batt(c: Context): Int {
        val b = bat(c)
        val l = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val s = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return l * 100 / s
    }
    // เวลาเชื่อมต่อ TCP ไปยัง 1.1.1.1 (ประมาณค่าปิงของเน็ตตอนนี้) คืน -1 ถ้าต่อไม่ได้
    fun ping(): Int = try {
        val t = System.nanoTime()
        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
        ((System.nanoTime() - t) / 1_000_000).toInt()
    } catch (e: Exception) { -1 }
}
